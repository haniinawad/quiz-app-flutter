// ignore_for_file: prefer_const_constructors, sized_box_for_whitespace

import 'package:flutter/material.dart';
class Splash extends StatelessWidget {
  const Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Scaffold(backgroundColor:Colors.white,
        body: Container(
            width: double.infinity,
            height: double.infinity,
           
             child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                 Image.asset('assets/images/img.png',width: 350,height: 333,),
                const SizedBox(height: 7,),
                const Padding(
                  padding: EdgeInsets.only(left: 27.0),
                  child: Text('Quiz app',style: TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w400),
                  ),
                ), SizedBox(height: 22,),
                  Center(
                    child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, "/login");
                    },
                    style: ButtonStyle(
                        backgroundColor: MaterialStatePropertyAll(
                          Colors.blue[160],
                        ),
                        padding: MaterialStatePropertyAll(
                            EdgeInsets.symmetric(horizontal: 60, vertical: 23)),
                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(29)))),
                    child: Text("GET STARTED")),
                  ),
              ],
              
            ),
            
          ),
          
          
        ),
    );

    
  }
}

