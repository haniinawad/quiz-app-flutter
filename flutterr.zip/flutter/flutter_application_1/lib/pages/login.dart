// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(   body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(hintText: 'Email'),
            ),
            SizedBox(height: 10),
            TextField(
              decoration: InputDecoration(hintText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, "/aboutUs");
              },
               style: ButtonStyle(
                backgroundColor: MaterialStatePropertyAll(
                  Color.fromARGB(239, 75, 87, 223),
                ),
                padding: MaterialStatePropertyAll(
                    EdgeInsets.symmetric(horizontal: 60, vertical: 23)),
                shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)))),
              child: Text('Login'),
            ),
            SizedBox(height: 20),
            TextButton(
              onPressed: () {
          
              },
              child: Text('Create an account'),
            ),
          ],
        ),
      ),
      
    );
  }
}
