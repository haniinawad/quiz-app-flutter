import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/splash.dart';
import 'package:flutter_application_1/pages/login.dart';
import 'package:flutter_application_1/pages/aboutUs.dart';



void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false,
    initialRoute: "/",
    routes: {"/aboutUs":(context) => const AboutUs(),
              "/login":(context) => const Login(),
              "/":(context) => const Splash()
    
    },
    
    );
  }
}
